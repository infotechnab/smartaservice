<div class="leftSide">
            <div class="menuItems">
                <ul class="menu">
                    <li class="mainMenuItem"> <a href="#">Product</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/product', 'Add New Product') ?></li>
                            <li><?php echo anchor('bnw/productList', 'List All Products') ?></li>
                            <li><?php echo anchor('bnw/productOrderList', 'List Order Product') ?></li>
                            <li><?php echo anchor('bnw/disproduct', 'Other List') ?></li>
                            <li><?php echo anchor('bnw/productShipping', 'Shipping ') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"> <a href="#">Control Panel</a>
                        <ul class="subMenu">
                            
                            <li><?php echo anchor('bnw', 'Home') ?></li>
                            <li><?php echo anchor('bnw/addmenu', 'Add Menu') ?></li>
                            <li><?php echo anchor('bnw/navigation', 'Navigation') ?></li>
                            <li><?php echo anchor('bnw/category', 'Categories') ?></li>
                        </ul>
                    </li>
                     <li class="mainMenuItem"><a href="#">Posts</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/posts', 'All Posts') ?></li>
                            <li><?php echo anchor('bnw/addpost', 'Add New Post') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Pages</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/pages', 'All Pages') ?></li>
                            <li><?php echo anchor('bnw/addpage', 'Add New') ?></li>                            
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Users</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/adduser', 'Add New') ?></li>
                            <li><?php echo anchor('bnw/users', 'All Users') ?></li>
                            <li><?php echo anchor('bnw/profile', 'My Profile') ?></li>
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Media</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/media', 'Library') ?></li>
                            <li><?php echo anchor('bnw/addmedia', 'Add New') ?></li>                           
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Social Share</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('social_share', 'Accounts') ?></li>
                            
                        </ul>
                    </li>
                    <li class="mainMenuItem"><a href="#">Settings</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/header', 'Header') ?></li>
                            <li><?php echo anchor('bnw/sidebar', 'Sidebar') ?></li>
                            <li><?php echo anchor('bnw/miscsetting', 'Miscellaneous Setting') ?></li>
                            <li><?php echo anchor('gadgets', 'Gadgets') ?></li>
                            
                            <li><?php echo anchor('bnw/setup', 'Setup') ?></li>
                        </ul>
                    </li>
                    
                    <li class="mainMenuItem"><a href="#">Album</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/addalbum', 'Add New') ?></li>
                            
                        </ul>
                    </li>
                    
                    <li class="mainMenuItem"><a href="#">Slider</a>
                        <ul class="subMenu">
                            <li><?php echo anchor('bnw/addslider', 'Add New') ?></li>
                            <li><?php echo anchor('bnw/slider', 'View All Slider') ?></li>
                        </ul>
                    </li>                    
                   
               </ul>   
            </div>
        </div>
        
        
        <!left side is cleared and closed here>
        