 <div id="footer">
                <p>copyright &COPY; 2014 wildsports - A complete solution for Trek and Sports wear .....</p>
                <p>site by : <a style="color:#ca021e;" href="http://salyani.com.np">Salyani</a></p>

            </div>




        </div>

    </body>
</html>

