<?php
    
    function get_currency($data)
    {
         echo '<span>$</span>'.'<span class="priceTag">'.$data.'</span>'."<span>/-</span>";   
    }
