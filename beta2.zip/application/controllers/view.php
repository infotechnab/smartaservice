<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class View extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->model('productModel');
        $this->load->helper('url');
        $this->load->library('cart');
        $this->load->helper(array('form', 'url', 'date'));
    }

    public function index() {     //fetching data from database of the product

        $data['product_info'] = $this->productModel->product_info();
        $data['featureItem'] = $this->productModel->featured_item();
        $this->load->view('templates/header');
        $this->load->view('templates/navigation');
        $this->load->view('templates/content', $data);
        $this->load->view('templates/cart');
        $this->load->view('templates/sidebarview');
        $this->load->view('templates/footer');
    }

 
 
	
        
        
        
        public function details($id){
            $data['product'] = $this->productModel->getProductById($id);
           
            $this->load->view('templates/header');
                $this->load->view('templates/navigation');
                $this->load->view('templates/details', $data);
                $this->load->view('templates/cart');
                $this->load->view('templates/sidebarview');
                $this->load->view('templates/footer');
        }
        
        public function login(){
            $this->load->view('templates/header');
                $this->load->view('templates/navigation');
                $this->load->view('templates/login');
             
                $this->load->view('templates/footer');
        }
        
     

    function add() {   //function to add item to the cart

        $id = $_POST['itemid'];

        $product = $this->productModel->getProductById($id);


        foreach ($product as $prod) {
            $name = $prod->name;
            $price = $prod->price;
            $image1 = $prod->image1;
        }
        $newQnt = 1;
        if ($this->cart->contents()) {
            $cart = $this->cart->contents();

            foreach ($cart as $item) {
                if (isset($item['id'])) {
                    if ($item['id'] == $id) {

                        $newQnt = 1;
                        $newQnt = $item['qty'] + 1;
                    }

                }
            }
        }

//        $tid = 0;
//         $trans_id = $this->productModel->getTranId();
//         foreach ($trans_id as $tranId)
//         {
//             $tid = $tranId->trans_id;
//         }
//         $a = "TRD";
//         $tid++;
//       $tid = $a.$tid;
//        

        $insert = array(
       //     'trans_id' => $tid,
            'id' => $id,
            'qty' => $newQnt,
            'price' => $price,
            'name' => $name,
            'image1' => $image1
        );
        $this->cart->insert($insert);
        $this->load->view('templates/cart');
    }

    function remove($rowid) {           //function to remove item from the cart
        $this->cart->update(array(
            'rowid' => $rowid,
            'qty' => 0
        ));
        redirect('view');
    }

    function clear() {          //function to clear the cart
        $this->cart->destroy();
        redirect('view');
    }

    function cart_details() {   //function to goto cart details
        $this->load->view('templates/header');
        $this->load->view('templates/navigation');
        $this->load->view('templates/cartDetails');

        $this->load->view('templates/footer');
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */