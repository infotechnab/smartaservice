 <div id="footer">
                <p>copyright &COPY; 2014 wildsports - A complete solution for Trek and Sports wear .....</p>
                <h6>Website design by: Salyani</h6>

            </div>




        </div>

    </body>
</html>

