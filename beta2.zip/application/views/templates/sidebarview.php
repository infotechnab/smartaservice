<div class="redColouredDiv" id='sidebarContent'><h3>Popular Posts</h3></div>
            <?php for ($i = 0; $i < 4; $i++) {
                ?>
                <div class='sidebarContentNext'></div>

<?php } ?>

            <div class="redColouredDiv" id='sidebarContent'><h3>Sponsors</h3></div>
            <?php for ($i = 0; $i < 4; $i++) {
                ?>
                <div class='sidebarContentNext'></div>

<?php } ?>
 <div class="clear"> </div>
        </div>  
       
 </div> 
 <div class="clear"> </div>
</div>