<div class="redColouredDiv" id="navigation">
    <div style="width: 70%; float: left;">
                        <ul>
                            <li><a href="<?php echo base_url().'index.php/view/index' ?>">HOME</a></li>
                            <li><a href="#">ABOUT US</a></li>
                            <li><a href="#">FEATURED</a></li>
                            <li><a href="#">ACCESSORIES</a></li>
                            <li><a href="#">KID'S</a></li>
                            <li><a href="#">MEN'S</a></li>
                            <li><a href="#">WOMEN'S</a></li>
                            <li><a href="#">CONTACT US</a></li>
    </div>
                            <div id='searchbox'>
<input type="text" placeholder="Search" style="box-shadow: inset 0px  #888, inset 0px  #888; outline: none; border: 1px solid #dddddd; padding: 6px; margin: 0px;" required/>
                            </div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div> 

            </div>