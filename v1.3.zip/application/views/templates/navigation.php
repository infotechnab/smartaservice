<div class="redColouredDiv" id="navigation">
    <div id="navigationLeft">
        <div id="cssmenu">
            <ul>
                <?php

            $this->load->helper('menumaker');

            fetch_menu (query(0));

        ?>
<!--                <li><a href="<?php //echo base_url().'index.php/view/index' ?>">HOME</a></li>
                 <li><a href="<?php //echo base_url().'index.php/view/pages' ?>">Caterory</a></li>
                            <li><a href="#">ABOUT US</a></li>
                            <li><a href="#">KID'S</a></li>
                            <li><a href="#">MEN'S</a></li>
                            <li><a href="#">WOMEN'S</a></li>
                            <li><a href="<?php //echo base_url().'index.php/view/contact' ?>">CONTACT US</a></li>-->
            </ul>
        </div>
                       
    </div>
                            <div id='searchbox'>
<input type="text" placeholder="Search" class="search" required/>
                            </div>
                        
                    </div>
                    <div class="clear"></div>
                </div> 

            </div>
            
            
            
 <div id="contentBackground">
    <div id='contentWrapper'>
        
            
