 <div id="footer">
                <p>copyright &COPY; 2014 Smart Access Services  - A complete solution for online shopping.....</p>
                <p>site by : <a style="color:#ca021e;" href="http://salyani.com.np">Salyani</a></p>
            </div>
        </div>

    </body>
</html>

