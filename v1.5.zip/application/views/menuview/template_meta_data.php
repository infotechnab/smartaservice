<?php

/*
 * meta data infromaio for template
 * 
 * Template Name: #
 * Template Author: #
 * Tempalte Type: Free
 * Template Created On: #
 * 
 */
function template_function()
{
$navigation_site=array('Choose Template', 'Header','Sidebar','Body','Footer');

//$menu_position=array("Header","Sidebar","Body","Footer");

return $navigation_site;
}
?>
